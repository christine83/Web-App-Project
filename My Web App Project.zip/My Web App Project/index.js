function reply()
{
event.preventDefault();
var myModal = new bootstrap.Modal(document.getElementById('exampleModal'), { keyboard: false })
myModal.show();  
}

function exercise()
{
event.preventDefault();
var exerciseModal = new bootstrap.Modal(document.getElementById('exampleModal'), { keyboard: false })
exerciseModal.show();  
}