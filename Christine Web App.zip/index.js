function reply()
{
event.preventDefault();
var myModal = new bootstrap.Modal(document.getElementById('exampleModal'), { keyboard: false })
myModal.show();  
}

function exercise()
{
event.preventDefault();
var exerciseModal = new bootstrap.Modal(document.getElementById('exerciseModal'), { keyboard: false })
exerciseModal.show();  
}

function food()
{
event.preventDefault();
var foodModal = new bootstrap.Modal(document.getElementById('foodModal'), { keyboard: false })
foodModal.show();  
}

function sleep()
{
event.preventDefault();

var sleepRecommendation = evaluateSleep(age_range, sleep_duration);

var sleepModal = new bootstrap.Modal(document.getElementById('sleepModal'), { keyboard: false })
sleepModal.show();

}



function evaluateSleep(age_range, sleep_duration){
    if(age_range == "Below 25" || "25 - 35" || "36 -45"){
        if(sleep_duration == "Less than 6 hours"){
            return "You need at least 6 to 7 hours of sleep.";
        }
    }
    if(age_range == "Below 25"| | "25 - 35" || "36 -45"){
        if(sleep_duration == "6 to 7 hours"){
            return "Try to sleep for 7 hours if you can.";
        }
    }
    if(age_range == "Below 25" || "25 - 35" || "36 -45"){
        if(sleep_duration == "7 to 8 hours"){
            return "Great to know you sleep sufficiently.";
        }
    }
    if(age_range == "Below 25" || "25 - 35" || "36 -45"){
        if(sleep_duration == "More than 8 hours"){
            return "You certainly sleep a lot.";
        }
    }
    if(age_range == "Above 45"){
        if(sleep_duration == "Less than 6 hours"){
            return "You need at least 6 to 7 hours of sleep.";
        }
    }
    if(age_range == "Above 45"){
        if(sleep_duration == "6 to 7 hours"){
            return "Great to know you sleep sufficiently";
        }
    }
    if(age_range == "Above 45"){
        if(sleep_duration == "7 to 8 hours"){
            return "You certainly sleep more.";
        }
    }
    if(age_range == "Above 45"){
        if(sleep_duration == "More than 8 hours"){
            return "You certainly sleep a lot.";
        }
    }
}